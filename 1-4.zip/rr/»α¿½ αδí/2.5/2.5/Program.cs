﻿using System;
using System.IO;

class FileExplorer
{
    static string currentDirectory = Directory.GetCurrentDirectory();

    static void Main(string[] args)
    {
        Console.Title = "Консольный файловый проводник";
        ShowMainMenu();
    }

    static void ShowMainMenu()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine($"Текущая директория: {currentDirectory}\n");
            Console.WriteLine("1. Просмотр содержимого каталога");
            Console.WriteLine("2. Перейти в подкаталог");
            Console.WriteLine("3. Вернуться в родительский каталог");
            Console.WriteLine("4. Создать каталог");
            Console.WriteLine("5. Создать текстовый файл");
            Console.WriteLine("6. Просмотреть текстовый файл");
            Console.WriteLine("7. Удалить файл или каталог");
            Console.WriteLine("8. Выход");

            Console.Write("\nВыберите действие (1-8): ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1": ShowDirectoryContents(); break;
                case "2": EnterSubdirectory(); break;
                case "3": GoToParentDirectory(); break;
                case "4": CreateNewDirectory(); break;
                case "5": CreateTextFile(); break;
                case "6": ViewTextFile(); break;
                case "7": DeleteItem(); break;
                case "8": Environment.Exit(0); break;
                default:
                    Console.WriteLine("Неверный выбор. Нажмите любую клавишу...");
                    Console.ReadKey();
                    break;
            }
        }
    }

    static void ShowDirectoryContents()
    {
        Console.Clear();
        Console.WriteLine($"Содержимое каталога {currentDirectory}:\n");

        try
        {
            // Показываем подкаталоги
            string[] directories = Directory.GetDirectories(currentDirectory);
            Console.WriteLine("[Каталоги]");
            foreach (string dir in directories)
            {
                Console.WriteLine($"  {Path.GetFileName(dir)}");
            }

            // Показываем файлы
            string[] files = Directory.GetFiles(currentDirectory);
            Console.WriteLine("\n[Файлы]");
            foreach (string file in files)
            {
                Console.WriteLine($"  {Path.GetFileName(file)}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }

        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }

    static void EnterSubdirectory()
    {
        Console.Clear();
        Console.WriteLine("Выберите каталог для перехода:\n");

        try
        {
            string[] directories = Directory.GetDirectories(currentDirectory);

            if (directories.Length == 0)
            {
                Console.WriteLine("В текущем каталоге нет подкаталогов.");
                Console.ReadKey();
                return;
            }

            for (int i = 0; i < directories.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {Path.GetFileName(directories[i])}");
            }

            Console.Write("\nВведите номер каталога (или 0 для отмены): ");
            if (int.TryParse(Console.ReadLine(), out int choice))
            {
                if (choice > 0 && choice <= directories.Length)
                {
                    currentDirectory = directories[choice - 1];
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
            Console.ReadKey();
        }
    }

    static void GoToParentDirectory()
    {
        try
        {
            DirectoryInfo parent = Directory.GetParent(currentDirectory);
            if (parent != null)
            {
                currentDirectory = parent.FullName;
            }
            else
            {
                Console.WriteLine("Вы находитесь в корневом каталоге.");
                Console.ReadKey();
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
            Console.ReadKey();
        }
    }

    static void CreateNewDirectory()
    {
        Console.Clear();
        Console.Write("Введите имя нового каталога: ");
        string dirName = Console.ReadLine();

        if (!string.IsNullOrWhiteSpace(dirName))
        {
            try
            {
                string newDirPath = Path.Combine(currentDirectory, dirName);
                Directory.CreateDirectory(newDirPath);
                Console.WriteLine($"Каталог '{dirName}' успешно создан.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при создании каталога: {ex.Message}");
            }
        }
        else
        {
            Console.WriteLine("Имя каталога не может быть пустым.");
        }

        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }

    static void CreateTextFile()
    {
        Console.Clear();
        Console.Write("Введите имя файла (с расширением .txt): ");
        string fileName = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(fileName))
        {
            Console.WriteLine("Имя файла не может быть пустым.");
            Console.ReadKey();
            return;
        }

        if (!fileName.EndsWith(".txt"))
        {
            fileName += ".txt";
        }

        try
        {
            string filePath = Path.Combine(currentDirectory, fileName);

            Console.WriteLine("\nВведите содержимое файла (для завершения введите пустую строку):\n");
            using (StreamWriter writer = File.CreateText(filePath))
            {
                string line;
                do
                {
                    line = Console.ReadLine();
                    if (!string.IsNullOrEmpty(line))
                    {
                        writer.WriteLine(line);
                    }
                } while (!string.IsNullOrEmpty(line));
            }

            Console.WriteLine($"\nФайл '{fileName}' успешно создан.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при создании файла: {ex.Message}");
        }

        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }

    static void ViewTextFile()
    {
        Console.Clear();
        Console.WriteLine("Доступные текстовые файлы (.txt):\n");

        try
        {
            string[] textFiles = Directory.GetFiles(currentDirectory, "*.txt");

            if (textFiles.Length == 0)
            {
                Console.WriteLine("В текущем каталоге нет текстовых файлов.");
                Console.ReadKey();
                return;
            }

            for (int i = 0; i < textFiles.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {Path.GetFileName(textFiles[i])}");
            }

            Console.Write("\nВведите номер файла для просмотра (или 0 для отмены): ");
            if (int.TryParse(Console.ReadLine(), out int choice) && choice > 0 && choice <= textFiles.Length)
            {
                Console.Clear();
                Console.WriteLine($"Содержимое файла {Path.GetFileName(textFiles[choice - 1])}:\n");

                using (StreamReader reader = File.OpenText(textFiles[choice - 1]))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        Console.WriteLine(line);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }

        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }

    static void DeleteItem()
    {
        Console.Clear();
        Console.WriteLine("1. Удалить файл");
        Console.WriteLine("2. Удалить каталог");
        Console.Write("\nВыберите тип объекта для удаления (1-2): ");
        string typeChoice = Console.ReadLine();

        try
        {
            if (typeChoice == "1")
            {
                string[] files = Directory.GetFiles(currentDirectory);

                if (files.Length == 0)
                {
                    Console.WriteLine("В текущем каталоге нет файлов.");
                    Console.ReadKey();
                    return;
                }

                Console.WriteLine("\nДоступные файлы:");
                for (int i = 0; i < files.Length; i++)
                {
                    Console.WriteLine($"{i + 1}. {Path.GetFileName(files[i])}");
                }

                Console.Write("\nВведите номер файла для удаления (или 0 для отмены): ");
                if (int.TryParse(Console.ReadLine(), out int fileChoice) && fileChoice > 0 && fileChoice <= files.Length)
                {
                    Console.Write($"Вы уверены, что хотите удалить файл '{Path.GetFileName(files[fileChoice - 1])}'? (y/n): ");
                    if (Console.ReadLine().ToLower() == "y")
                    {
                        File.Delete(files[fileChoice - 1]);
                        Console.WriteLine("Файл успешно удален.");
                    }
                }
            }
            else if (typeChoice == "2")
            {
                string[] directories = Directory.GetDirectories(currentDirectory);

                if (directories.Length == 0)
                {
                    Console.WriteLine("В текущем каталоге нет подкаталогов.");
                    Console.ReadKey();
                    return;
                }

                Console.WriteLine("\nДоступные каталоги:");
                for (int i = 0; i < directories.Length; i++)
                {
                    Console.WriteLine($"{i + 1}. {Path.GetFileName(directories[i])}");
                }

                Console.Write("\nВведите номер каталога для удаления (или 0 для отмены): ");
                if (int.TryParse(Console.ReadLine(), out int dirChoice) && dirChoice > 0 && dirChoice <= directories.Length)
                {
                    Console.Write($"Вы уверены, что хотите удалить каталог '{Path.GetFileName(directories[dirChoice - 1])}'? (y/n): ");
                    if (Console.ReadLine().ToLower() == "y")
                    {
                        Directory.Delete(directories[dirChoice - 1], true);
                        Console.WriteLine("Каталог успешно удален.");
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при удалении: {ex.Message}");
        }

        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }
}