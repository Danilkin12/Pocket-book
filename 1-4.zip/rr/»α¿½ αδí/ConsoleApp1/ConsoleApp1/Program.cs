﻿using System;

class AreaCalculator
{
    // Площадь квадрата
    public double CalculateArea(double a)
    {
        return a * a;
    }

    // Площадь прямоугольника
    public double CalculateArea(double a, double b)
    {
        return a * b;
    }

    // Площадь прямоугольного треугольника
    public double CalculateArea(double a, double b, bool isTriangle)
    {
        if (isTriangle)
            return a * b / 2;
        else
            throw new ArgumentException("Для треугольника третий параметр должен быть true");
    }

    // Площадь трапеции
    public double CalculateArea(double a, double b, double h)
    {
        return (a + b) * h / 2;
    }
}

class Program
{
    static void Main(string[] args)
    {
        AreaCalculator calculator = new AreaCalculator();

        double squareArea = calculator.CalculateArea(5);
        Console.WriteLine($"Площадь квадрата со стороной 5 равна {squareArea}");

        double rectangleArea = calculator.CalculateArea(4, 6);
        Console.WriteLine($"Площадь прямоугольника со сторонами 4 и 6 равна {rectangleArea}");

        double triangleArea = calculator.CalculateArea(3, 4, true);
        Console.WriteLine($"Площадь прямоугольного треугольника с катетами 3 и 4 равна {triangleArea}");

        double trapezoidArea = calculator.CalculateArea(5, 7, 4);
        Console.WriteLine($"Площадь трапеции с основаниями 5 и 7 и высотой 4 равна {trapezoidArea}");
    }
}