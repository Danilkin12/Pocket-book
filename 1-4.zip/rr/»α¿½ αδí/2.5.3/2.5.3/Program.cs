﻿using System;
using System.IO;
using System.Text;

class EnhancedFileExplorer
{
    private static string currentDirectory = Directory.GetCurrentDirectory();

    static void Main(string[] args)
    {
        Console.Title = "Улучшенный файловый проводник";
        Console.OutputEncoding = Encoding.UTF8;
        ShowMainMenu();
    }

    static void ShowMainMenu()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("=== УЛУЧШЕННЫЙ ФАЙЛОВЫЙ ПРОВОДНИК ===");
            Console.WriteLine($"Текущее расположение: {currentDirectory}\n");
            Console.WriteLine("1. Просмотреть диски");
            Console.WriteLine("2. Информация о текущем диске");
            Console.WriteLine("3. Просмотр содержимого");
            Console.WriteLine("4. Создать каталог");
            Console.WriteLine("5. Создать текстовый файл (с расширенным редактором)");
            Console.WriteLine("6. Удалить файл/каталог");
            Console.WriteLine("7. Сменить диск/каталог");
            Console.WriteLine("8. Выход");

            Console.Write("\nВыберите действие (1-8): ");
            var choice = Console.ReadLine();

            switch (choice)
            {
                case "1": ShowAllDrives(); break;
                case "2": ShowCurrentDriveInfo(); break;
                case "3": BrowseDirectory(); break;
                case "4": CreateNewDirectory(); break;
                case "5": CreateTextFileWithEditor(); break;
                case "6": DeleteFileOrDirectory(); break;
                case "7": ChangeLocation(); break;
                case "8": return;
                default:
                    Console.WriteLine("\nНеверный ввод! Нажмите любую клавишу...");
                    Console.ReadKey();
                    break;
            }
        }
    }

    static void ShowAllDrives()
    {
        Console.Clear();
        Console.WriteLine("ДОСТУПНЫЕ ДИСКИ:\n");

        DriveInfo[] drives = DriveInfo.GetDrives();
        int index = 1;

        foreach (var drive in drives)
        {
            Console.Write($"{index++}. {drive.Name}");

            if (drive.IsReady)
            {
                Console.WriteLine($" ({drive.DriveFormat}, {FormatSize(drive.AvailableFreeSpace)} свободно)");
            }
            else
            {
                Console.WriteLine(" (не готов)");
            }
        }

        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }

    static void ShowCurrentDriveInfo()
    {
        Console.Clear();
        try
        {
            var drive = new DriveInfo(Path.GetPathRoot(currentDirectory));

            if (!drive.IsReady)
            {
                Console.WriteLine("Диск не готов к использованию!");
                Console.ReadKey();
                return;
            }

            Console.WriteLine($"ИНФОРМАЦИЯ О ДИСКЕ {drive.Name}:\n");
            Console.WriteLine($"Метка тома: {drive.VolumeLabel}");
            Console.WriteLine($"Тип: {drive.DriveType}");
            Console.WriteLine($"Формат: {drive.DriveFormat}");
            Console.WriteLine($"Общий размер: {FormatSize(drive.TotalSize)}");
            Console.WriteLine($"Доступно: {FormatSize(drive.AvailableFreeSpace)}");
            Console.WriteLine($"Использовано: {FormatSize(drive.TotalSize - drive.TotalFreeSpace)}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }

        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }

    static void BrowseDirectory()
    {
        Console.Clear();
        Console.WriteLine($"СОДЕРЖИМОЕ: {currentDirectory}\n");

        try
        {
            // Отображаем каталоги
            Console.WriteLine("[КАТАЛОГИ]");
            var directories = Directory.GetDirectories(currentDirectory);
            for (int i = 0; i < directories.Length; i++)
            {
                var dirInfo = new DirectoryInfo(directories[i]);
                Console.WriteLine($"  {i + 1}. {dirInfo.Name,-40} {dirInfo.CreationTime:dd.MM.yyyy HH:mm}");
            }

            // Отображаем файлы
            Console.WriteLine("\n[ФАЙЛЫ]");
            var files = Directory.GetFiles(currentDirectory);
            for (int i = 0; i < files.Length; i++)
            {
                var fileInfo = new FileInfo(files[i]);
                Console.WriteLine($"  {i + 1 + directories.Length}. {fileInfo.Name,-40} {FormatSize(fileInfo.Length),10} {fileInfo.CreationTime:dd.MM.yyyy HH:mm}");
            }

            Console.Write("\nВведите номер для перехода (0 - назад): ");
            if (int.TryParse(Console.ReadLine(), out int choice))
            {
                if (choice > 0 && choice <= directories.Length + files.Length)
                {
                    if (choice <= directories.Length)
                    {
                        currentDirectory = directories[choice - 1];
                    }
                    else
                    {
                        ViewFileContent(files[choice - directories.Length - 1]);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
            Console.ReadKey();
        }
    }

    static void ViewFileContent(string filePath)
    {
        Console.Clear();
        Console.WriteLine($"СОДЕРЖИМОЕ ФАЙЛА: {Path.GetFileName(filePath)}\n");

        try
        {
            if (new FileInfo(filePath).Length > 1024 * 1024) // > 1MB
            {
                Console.WriteLine("Файл слишком большой для просмотра в проводнике.");
                Console.ReadKey();
                return;
            }

            using (var reader = new StreamReader(filePath))
            {
                string line;
                int lineCount = 0;
                while ((line = reader.ReadLine()) != null && lineCount++ < 100) // Ограничиваем 100 строками
                {
                    Console.WriteLine(line);
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при чтении файла: {ex.Message}");
        }

        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }

    static void CreateNewDirectory()
    {
        Console.Clear();
        Console.Write("Введите имя нового каталога: ");
        string dirName = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(dirName))
        {
            Console.WriteLine("Имя каталога не может быть пустым!");
            Console.ReadKey();
            return;
        }

        try
        {
            string newDirPath = Path.Combine(currentDirectory, dirName);
            Directory.CreateDirectory(newDirPath);
            Console.WriteLine($"Каталог '{dirName}' успешно создан в {currentDirectory}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при создании каталога: {ex.Message}");
        }

        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }

    static void CreateTextFileWithEditor()
    {
        Console.Clear();
        Console.WriteLine("СОЗДАНИЕ НОВОГО ТЕКСТОВОГО ФАЙЛА\n");
        Console.Write("Введите имя файла (с расширением .txt): ");
        string fileName = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(fileName))
        {
            Console.WriteLine("Имя файла не может быть пустым!");
            Console.ReadKey();
            return;
        }

        if (!fileName.EndsWith(".txt", StringComparison.OrdinalIgnoreCase))
        {
            fileName += ".txt";
        }

        try
        {
            string filePath = Path.Combine(currentDirectory, fileName);

            Console.WriteLine("\nРедактор текста (для сохранения введите команду :wq на новой строке)\n");
            Console.WriteLine("Содержимое файла:");

            using (var writer = new StreamWriter(filePath))
            {
                string line;
                int lineNumber = 1;

                while (true)
                {
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.Write($"{lineNumber++} | ");
                    Console.ResetColor();

                    line = Console.ReadLine();

                    if (line == ":wq") break;

                    writer.WriteLine(line);
                }
            }

            Console.WriteLine($"\nФайл '{fileName}' успешно создан в {currentDirectory}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при создании файла: {ex.Message}");
        }

        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }

    static void DeleteFileOrDirectory()
    {
        Console.Clear();
        Console.WriteLine("УДАЛЕНИЕ ФАЙЛА ИЛИ КАТАЛОГА\n");
        Console.WriteLine("1. Удалить файл");
        Console.WriteLine("2. Удалить каталог");
        Console.Write("\nВыберите действие (1-2): ");
        var choice = Console.ReadLine();

        try
        {
            if (choice == "1")
            {
                var files = Directory.GetFiles(currentDirectory);
                if (files.Length == 0)
                {
                    Console.WriteLine("Нет файлов для удаления.");
                    Console.ReadKey();
                    return;
                }

                Console.WriteLine("\nДоступные файлы:");
                for (int i = 0; i < files.Length; i++)
                {
                    Console.WriteLine($"{i + 1}. {Path.GetFileName(files[i])}");
                }

                Console.Write("\nВведите номер файла для удаления (0 - отмена): ");
                if (int.TryParse(Console.ReadLine(), out int fileNum) && fileNum > 0 && fileNum <= files.Length)
                {
                    string fileToDelete = files[fileNum - 1];
                    Console.Write($"Вы уверены, что хотите удалить файл '{Path.GetFileName(fileToDelete)}'? (y/n): ");
                    if (Console.ReadLine().ToLower() == "y")
                    {
                        File.Delete(fileToDelete);
                        Console.WriteLine("Файл успешно удален!");
                    }
                }
            }
            else if (choice == "2")
            {
                var dirs = Directory.GetDirectories(currentDirectory);
                if (dirs.Length == 0)
                {
                    Console.WriteLine("Нет каталогов для удаления.");
                    Console.ReadKey();
                    return;
                }

                Console.WriteLine("\nДоступные каталоги:");
                for (int i = 0; i < dirs.Length; i++)
                {
                    Console.WriteLine($"{i + 1}. {Path.GetFileName(dirs[i])}");
                }

                Console.Write("\nВведите номер каталога для удаления (0 - отмена): ");
                if (int.TryParse(Console.ReadLine(), out int dirNum) && dirNum > 0 && dirNum <= dirs.Length)
                {
                    string dirToDelete = dirs[dirNum - 1];
                    Console.Write($"Вы уверены, что хотите удалить каталог '{Path.GetFileName(dirToDelete)}'? (y/n): ");
                    if (Console.ReadLine().ToLower() == "y")
                    {
                        Directory.Delete(dirToDelete, true);
                        Console.WriteLine("Каталог успешно удален!");
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при удалении: {ex.Message}");
        }

        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }

    static void ChangeLocation()
    {
        Console.Clear();
        Console.WriteLine("СМЕНА ТЕКУЩЕГО РАСПОЛОЖЕНИЯ\n");
        Console.WriteLine("1. Выбрать диск");
        Console.WriteLine("2. Перейти в родительский каталог");
        Console.Write("\nВыберите действие (1-2): ");
        var choice = Console.ReadLine();

        try
        {
            if (choice == "1")
            {
                var drives = DriveInfo.GetDrives();
                Console.WriteLine("\nДоступные диски:");
                for (int i = 0; i < drives.Length; i++)
                {
                    Console.WriteLine($"{i + 1}. {drives[i].Name} {(drives[i].IsReady ? "(готов)" : "(не готов)")}");
                }

                Console.Write("\nВведите номер диска (0 - отмена): ");
                if (int.TryParse(Console.ReadLine(), out int driveNum) && driveNum > 0 && driveNum <= drives.Length)
                {
                    if (drives[driveNum - 1].IsReady)
                    {
                        currentDirectory = drives[driveNum - 1].RootDirectory.FullName;
                    }
                    else
                    {
                        Console.WriteLine("Диск не готов к использованию!");
                        Console.ReadKey();
                    }
                }
            }
            else if (choice == "2")
            {
                var parent = Directory.GetParent(currentDirectory);
                if (parent != null)
                {
                    currentDirectory = parent.FullName;
                }
                else
                {
                    Console.WriteLine("Это корневой каталог!");
                    Console.ReadKey();
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
            Console.ReadKey();
        }
    }

    static string FormatSize(long bytes)
    {
        string[] sizes = { "B", "KB", "MB", "GB", "TB" };
        double len = bytes;
        int order = 0;
        while (len >= 1024 && order < sizes.Length - 1)
        {
            order++;
            len /= 1024;
        }
        return $"{len:0.##} {sizes[order]}";
    }
}