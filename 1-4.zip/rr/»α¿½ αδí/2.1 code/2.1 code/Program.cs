﻿using System;

class ReservoirCalculator
{
    static void Main()
    {
        Console.WriteLine("Расчет массы вещества в резервуаре");

        // Ввод исходных данных
        Console.Write("Введите начальную массу вещества P (кг): ");
        double P = double.Parse(Console.ReadLine());

        Console.Write("Введите ежедневное изъятие T (кг): ");
        double T = double.Parse(Console.ReadLine());

        Console.Write("Введите процент ежедневного испарения q (%): ");
        double q = double.Parse(Console.ReadLine());

        Console.Write("Введите количество дней N: ");
        int N = int.Parse(Console.ReadLine());

        // Проверка условий задачи
        if (P <= N * T)
        {
            Console.WriteLine("Ошибка: Начальная масса P должна быть значительно больше N*T");
            return;
        }

        // Расчет и вывод результатов
        Console.WriteLine("\nРезультаты расчета:");
        Console.WriteLine("День\tМасса на конец дня (кг)");

        double currentMass = P;

        for (int day = 1; day <= N; day++)
        {
            // Изъятие вещества в начале дня
            currentMass -= T;

            // Испарение в течение дня
            currentMass *= (100 - q) / 100;

            // Вывод результата для текущего дня
            Console.WriteLine($"{day}\t{currentMass:F3}");
        }
    }
}