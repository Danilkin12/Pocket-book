﻿using System;
using System.IO;
using System.Linq;

class DiskManager
{
    private static string currentDirectory;

    static void Main(string[] args)
    {
        Console.Title = "Менеджер дисков";
        currentDirectory = Directory.GetCurrentDirectory();
        ShowMainMenu();
    }

    static void ShowMainMenu()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("=== МЕНЕДЖЕР ДИСКОВ ===");
            Console.WriteLine($"Текущий путь: {currentDirectory}\n");
            Console.WriteLine("1. Просмотреть доступные диски");
            Console.WriteLine("2. Информация о текущем диске");
            Console.WriteLine("3. Просмотр содержимого текущего диска");
            Console.WriteLine("4. Создать каталог");
            Console.WriteLine("5. Создать текстовый файл");
            Console.WriteLine("6. Удалить файл или каталог");
            Console.WriteLine("7. Сменить текущий диск");
            Console.WriteLine("8. Выход");

            Console.Write("\nВыберите действие (1-8): ");
            var choice = Console.ReadLine();

            switch (choice)
            {
                case "1": ShowAvailableDrives(); break;
                case "2": ShowDriveInfo(); break;
                case "3": ShowDirectoryContents(); break;
                case "4": CreateDirectory(); break;
                case "5": CreateTextFile(); break;
                case "6": DeleteItem(); break;
                case "7": ChangeDrive(); break;
                case "8": return;
                default:
                    Console.WriteLine("Неверный ввод! Нажмите любую клавишу...");
                    Console.ReadKey();
                    break;
            }
        }
    }

    static void ShowAvailableDrives()
    {
        Console.Clear();
        Console.WriteLine("ДОСТУПНЫЕ ДИСКИ:\n");

        DriveInfo[] drives = DriveInfo.GetDrives();
        for (int i = 0; i < drives.Length; i++)
        {
            var drive = drives[i];
            Console.Write($"{i + 1}. {drive.Name}");

            if (drive.IsReady)
            {
                Console.WriteLine($" ({drive.DriveFormat}, {drive.AvailableFreeSpace / (1024 * 1024 * 1024)} GB свободно)");
            }
            else
            {
                Console.WriteLine(" (не готов)");
            }
        }

        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }

    static void ShowDriveInfo()
    {
        Console.Clear();
        try
        {
            DriveInfo drive = new DriveInfo(Path.GetPathRoot(currentDirectory));

            if (!drive.IsReady)
            {
                Console.WriteLine("Диск не готов к использованию!");
                Console.ReadKey();
                return;
            }

            Console.WriteLine($"ИНФОРМАЦИЯ О ДИСКЕ {drive.Name}:\n");
            Console.WriteLine($"Метка тома: {drive.VolumeLabel}");
            Console.WriteLine($"Тип диска: {drive.DriveType}");
            Console.WriteLine($"Файловая система: {drive.DriveFormat}");
            Console.WriteLine($"Общий размер: {drive.TotalSize / (1024 * 1024 * 1024)} GB");
            Console.WriteLine($"Свободно: {drive.TotalFreeSpace / (1024 * 1024 * 1024)} GB");
            Console.WriteLine($"Занято: {(drive.TotalSize - drive.TotalFreeSpace) / (1024 * 1024 * 1024)} GB");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }

        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }

    static void ShowDirectoryContents()
    {
        Console.Clear();
        Console.WriteLine($"СОДЕРЖИМОЕ ДИСКА {Path.GetPathRoot(currentDirectory)}:\n");
        Console.WriteLine($"Текущий каталог: {currentDirectory}\n");

        try
        {
            // Показать подкаталоги
            var directories = Directory.GetDirectories(currentDirectory);
            Console.WriteLine("[КАТАЛОГИ]");
            foreach (var dir in directories)
            {
                var dirInfo = new DirectoryInfo(dir);
                Console.WriteLine($"  {dirInfo.Name,-40} {dirInfo.CreationTime}");
            }

            // Показать файлы
            var files = Directory.GetFiles(currentDirectory);
            Console.WriteLine("\n[ФАЙЛЫ]");
            foreach (var file in files)
            {
                var fileInfo = new FileInfo(file);
                Console.WriteLine($"  {fileInfo.Name,-40} {fileInfo.Length / 1024} KB");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }

        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }

    static void CreateDirectory()
    {
        Console.Clear();
        Console.Write("Введите имя нового каталога: ");
        string dirName = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(dirName))
        {
            Console.WriteLine("Имя каталога не может быть пустым!");
            Console.ReadKey();
            return;
        }

        try
        {
            string newPath = Path.Combine(currentDirectory, dirName);
            Directory.CreateDirectory(newPath);
            Console.WriteLine($"Каталог '{dirName}' успешно создан!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при создании каталога: {ex.Message}");
        }

        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }

    static void CreateTextFile()
    {
        Console.Clear();
        Console.Write("Введите имя текстового файла (с расширением .txt): ");
        string fileName = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(fileName))
        {
            Console.WriteLine("Имя файла не может быть пустым!");
            Console.ReadKey();
            return;
        }

        if (!fileName.EndsWith(".txt"))
        {
            fileName += ".txt";
        }

        try
        {
            string filePath = Path.Combine(currentDirectory, fileName);

            Console.WriteLine("\nВведите содержимое файла (для завершения введите пустую строку):");
            using (StreamWriter writer = File.CreateText(filePath))
            {
                string line;
                do
                {
                    Console.Write("> ");
                    line = Console.ReadLine();
                    if (!string.IsNullOrEmpty(line))
                    {
                        writer.WriteLine(line);
                    }
                } while (!string.IsNullOrEmpty(line));
            }

            Console.WriteLine($"\nФайл '{fileName}' успешно создан!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при создании файла: {ex.Message}");
        }

        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }

    static void DeleteItem()
    {
        Console.Clear();
        Console.WriteLine("1. Удалить файл");
        Console.WriteLine("2. Удалить каталог");
        Console.Write("\nВыберите действие (1-2): ");
        string choice = Console.ReadLine();

        try
        {
            if (choice == "1")
            {
                var files = Directory.GetFiles(currentDirectory);
                if (files.Length == 0)
                {
                    Console.WriteLine("Нет файлов для удаления.");
                    Console.ReadKey();
                    return;
                }

                Console.WriteLine("\nДоступные файлы:");
                for (int i = 0; i < files.Length; i++)
                {
                    Console.WriteLine($"{i + 1}. {Path.GetFileName(files[i])}");
                }

                Console.Write("\nВведите номер файла для удаления (0 для отмены): ");
                if (int.TryParse(Console.ReadLine(), out int fileNum) && fileNum > 0 && fileNum <= files.Length)
                {
                    string fileToDelete = files[fileNum - 1];
                    Console.Write($"Вы уверены, что хотите удалить файл '{Path.GetFileName(fileToDelete)}'? (y/n): ");
                    if (Console.ReadLine().ToLower() == "y")
                    {
                        File.Delete(fileToDelete);
                        Console.WriteLine("Файл успешно удален!");
                    }
                }
            }
            else if (choice == "2")
            {
                var dirs = Directory.GetDirectories(currentDirectory);
                if (dirs.Length == 0)
                {
                    Console.WriteLine("Нет каталогов для удаления.");
                    Console.ReadKey();
                    return;
                }

                Console.WriteLine("\nДоступные каталоги:");
                for (int i = 0; i < dirs.Length; i++)
                {
                    Console.WriteLine($"{i + 1}. {Path.GetFileName(dirs[i])}");
                }

                Console.Write("\nВведите номер каталога для удаления (0 для отмены): ");
                if (int.TryParse(Console.ReadLine(), out int dirNum) && dirNum > 0 && dirNum <= dirs.Length)
                {
                    string dirToDelete = dirs[dirNum - 1];
                    Console.Write($"Вы уверены, что хотите удалить каталог '{Path.GetFileName(dirToDelete)}'? (y/n): ");
                    if (Console.ReadLine().ToLower() == "y")
                    {
                        Directory.Delete(dirToDelete, true);
                        Console.WriteLine("Каталог успешно удален!");
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при удалении: {ex.Message}");
        }

        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }

    static void ChangeDrive()
    {
        Console.Clear();
        DriveInfo[] drives = DriveInfo.GetDrives();
        Console.WriteLine("ДОСТУПНЫЕ ДИСКИ:\n");

        for (int i = 0; i < drives.Length; i++)
        {
            Console.WriteLine($"{i + 1}. {drives[i].Name}");
        }

        Console.Write("\nВыберите диск для перехода (0 для отмены): ");
        if (int.TryParse(Console.ReadLine(), out int choice) && choice > 0 && choice <= drives.Length)
        {
            if (drives[choice - 1].IsReady)
            {
                currentDirectory = drives[choice - 1].RootDirectory.FullName;
            }
            else
            {
                Console.WriteLine("Диск не готов к использованию!");
                Console.ReadKey();
            }
        }
    }
}