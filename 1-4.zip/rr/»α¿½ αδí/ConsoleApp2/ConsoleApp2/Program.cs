﻿using System;

abstract class Shape
{
    public abstract double CalculateArea();
}

class Square : Shape
{
    public double Side { get; set; }

    public Square(double side)
    {
        Side = side;
    }

    public override double CalculateArea()
    {
        return Side * Side;
    }
}

class Rectangle : Shape
{
    public double Width { get; set; }
    public double Height { get; set; }

    public Rectangle(double width, double height)
    {
        Width = width;
        Height = height;
    }

    public override double CalculateArea()
    {
        return Width * Height;
    }
}

class RightTriangle : Shape
{
    public double LegA { get; set; }
    public double LegB { get; set; }

    public RightTriangle(double legA, double legB)
    {
        LegA = legA;
        LegB = legB;
    }

    public override double CalculateArea()
    {
        return LegA * LegB / 2;
    }
}

class Trapezoid : Shape
{
    public double BaseA { get; set; }
    public double BaseB { get; set; }
    public double Height { get; set; }

    public Trapezoid(double baseA, double baseB, double height)
    {
        BaseA = baseA;
        BaseB = baseB;
        Height = height;
    }

    public override double CalculateArea()
    {
        return (BaseA + BaseB) * Height / 2;
    }
}

class Program
{
    static void Main(string[] args)
    {
        Shape[] shapes = new Shape[]
        {
            new Square(5),
            new Rectangle(4, 6),
            new RightTriangle(3, 4),
            new Trapezoid(5, 7, 4)
        };

        foreach (var shape in shapes)
        {
            Console.WriteLine($"Площадь {shape.GetType().Name} равна {shape.CalculateArea()}");
        }
    }
}