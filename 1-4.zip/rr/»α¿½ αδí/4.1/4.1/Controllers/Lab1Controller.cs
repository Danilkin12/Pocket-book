﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace VegetableListApp.Controllers
{
    public class VegetableController : Controller
    {
        // Метод для формирования списка овощей
        private List<string> GetVegetables()
        {
            return new List<string>
            {
                "Морковь", "Картофель", "Лук", "Помидор",
                "Огурец", "Капуста", "Баклажан", "Кабачок"
            };
        }

        // Первое представление - простой список
        public ActionResult FirstViewMethod()
        {
            ViewBag.Vegetables = GetVegetables();
            return View();
        }

        // Второе представление - отсортированная таблица
        public ActionResult SecondViewMethod()
        {
            var vegetables = GetVegetables().OrderBy(v => v).ToList();
            return View(vegetables);
        }

        // Третье представление - группировка по первой букве
        public ActionResult ThirdViewMethod()
        {
            var groupedVegetables = GetVegetables()
                .OrderBy(v => v)
                .GroupBy(v => v[0])
                .ToList();
            return View(groupedVegetables);
        }
    }
}