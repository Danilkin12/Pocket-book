﻿using Microsoft.AspNetCore.Mvc;

namespace _4._1
{
    public class RouteConfig : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
