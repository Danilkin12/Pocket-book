import os
from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# Конфигурация
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'pdf'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Инициализация Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Создание папки для загрузок
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Инициализация базы данных
def init_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL,
        email TEXT UNIQUE
    )
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS books (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        author_id INTEGER NOT NULL,
        filename TEXT NOT NULL,
        description TEXT,
        upload_date TEXT NOT NULL,
        FOREIGN KEY (author_id) REFERENCES users(id)
    )
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        book_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        text TEXT NOT NULL,
        date TEXT NOT NULL,
        rating INTEGER,
        FOREIGN KEY (book_id) REFERENCES books(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    )
    ''')
    
    # Создание администратора по умолчанию
    cursor.execute('SELECT * FROM users WHERE username = ?', ('admin',))
    if not cursor.fetchone():
        cursor.execute('INSERT INTO users (username, password, role, email) VALUES (?, ?, ?, ?)',
                      ('admin', generate_password_hash('admin'), 'admin', 'admin@example.com'))
    
    conn.commit()
    conn.close()

init_db()

class User(UserMixin):
    def __init__(self, id, username, password, role, email=None):
        self.id = id
        self.username = username
        self.password = password
        self.role = role
        self.email = email

    @staticmethod
    def get(user_id):
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))
        user_data = cursor.fetchone()
        conn.close()
        
        if not user_data:
            return None
        return User(*user_data)

@login_manager.user_loader
def load_user(user_id):
    return User.get(user_id)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    cursor.execute('''
    SELECT books.id, books.title, users.username, books.description, books.upload_date, 
           AVG(comments.rating) as avg_rating, books.filename, books.author_id
    FROM books
    JOIN users ON books.author_id = users.id
    LEFT JOIN comments ON books.id = comments.book_id
    GROUP BY books.id
    ORDER BY books.upload_date DESC
    ''')
    books = cursor.fetchall()
    
    conn.close()
    return render_template('index.html', books=books)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
        user_data = cursor.fetchone()
        conn.close()
        
        if user_data and check_password_hash(user_data[2], password):
            user = User(*user_data)
            login_user(user)
            flash('Вы успешно вошли в систему', 'success')
            return redirect(url_for('index'))
        else:
            flash('Неверное имя пользователя или пароль', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Вы вышли из системы', 'success')
    return redirect(url_for('index'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form.get('email', '')
        role = request.form.get('role', 'user')  # По умолчанию 'user'
        
        # Остальная логика проверки и создания пользователя
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        
        # Проверка существования пользователя
        cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
        if cursor.fetchone():
            flash('Пользователь с таким именем уже существует', 'error')
            conn.close()
            return redirect(url_for('register'))
        
        # Создание пользователя
        cursor.execute('INSERT INTO users (username, password, role, email) VALUES (?, ?, ?, ?)',
                      (username, generate_password_hash(password), role, email))
        conn.commit()
        conn.close()
        
        flash('Регистрация прошла успешно. Теперь вы можете войти.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
    if current_user.role not in ['admin', 'author']:
        flash('У вас нет прав для загрузки книг', 'error')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        title = request.form['title']
        description = request.form.get('description', '')
        file = request.files['file']
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            
            if os.path.exists(filepath):
                flash('Файл с таким именем уже существует', 'error')
                return redirect(url_for('upload'))
            
            file.save(filepath)
            
            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()
            cursor.execute('INSERT INTO books (title, author_id, filename, description, upload_date) VALUES (?, ?, ?, ?, ?)',
                          (title, current_user.id, filename, description, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            conn.commit()
            conn.close()
            
            flash('Книга успешно загружена', 'success')
            return redirect(url_for('index'))
        else:
            flash('Разрешены только файлы PDF', 'error')
    
    return render_template('upload.html')

@app.route('/book/<int:book_id>', methods=['GET', 'POST'])
def book(book_id):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    if request.method == 'POST' and current_user.is_authenticated:
        text = request.form.get('text', '')
        rating = request.form.get('rating', None)
        
        if text or rating:
            cursor.execute('INSERT INTO comments (book_id, user_id, text, date, rating) VALUES (?, ?, ?, ?, ?)',
                          (book_id, current_user.id, text, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), rating))
            conn.commit()
            flash('Комментарий добавлен', 'success')
    
    cursor.execute('''
    SELECT books.id, books.title, books.description, books.filename, books.upload_date, 
           users.username, users.id as author_id, AVG(comments.rating) as avg_rating
    FROM books
    JOIN users ON books.author_id = users.id
    LEFT JOIN comments ON books.id = comments.book_id
    WHERE books.id = ?
    GROUP BY books.id
    ''', (book_id,))
    book_data = cursor.fetchone()
    
    if not book_data:
        conn.close()
        flash('Книга не найдена', 'error')
        return redirect(url_for('index'))
    
    cursor.execute('''
    SELECT comments.text, comments.date, comments.rating, users.username
    FROM comments
    JOIN users ON comments.user_id = users.id
    WHERE comments.book_id = ?
    ORDER BY comments.date DESC
    ''', (book_id,))
    comments = cursor.fetchall()
    
    conn.close()
    return render_template('book.html', book=book_data, comments=comments)

@app.route('/download/<filename>')
def download(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=True)

@app.route('/admin')
@login_required
def admin_panel():
    if current_user.role != 'admin':
        flash('У вас нет прав доступа к этой странице', 'error')
        return redirect(url_for('index'))
    
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    cursor.execute('SELECT id, username, role, email FROM users')
    users = cursor.fetchall()
    
    cursor.execute('''
    SELECT books.id, books.title, users.username, books.filename, books.upload_date
    FROM books
    JOIN users ON books.author_id = users.id
    ORDER BY books.upload_date DESC
    ''')
    books = cursor.fetchall()
    
    conn.close()
    return render_template('admin.html', users=users, books=books)

@app.route('/delete_book/<int:book_id>')
@login_required
def delete_book(book_id):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    cursor.execute('SELECT author_id, filename FROM books WHERE id = ?', (book_id,))
    book_data = cursor.fetchone()
    
    if not book_data:
        conn.close()
        flash('Книга не найдена', 'error')
        return redirect(url_for('index'))
    
    if current_user.role != 'admin' and current_user.id != book_data[0]:
        conn.close()
        flash('У вас нет прав для удаления этой книги', 'error')
        return redirect(url_for('index'))
    
    try:
        os.remove(os.path.join(app.config['UPLOAD_FOLDER'], book_data[1]))
    except OSError:
        pass
    
    cursor.execute('DELETE FROM books WHERE id = ?', (book_id,))
    cursor.execute('DELETE FROM comments WHERE book_id = ?', (book_id,))
    conn.commit()
    conn.close()
    
    flash('Книга успешно удалена', 'success')
    return redirect(request.referrer or url_for('index'))

@app.route('/delete_user/<int:user_id>')
@login_required
def delete_user(user_id):
    if current_user.role != 'admin':
        flash('У вас нет прав для удаления пользователей', 'error')
        return redirect(url_for('index'))
    
    if current_user.id == user_id:
        flash('Вы не можете удалить самого себя', 'error')
        return redirect(url_for('admin_panel'))
    
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    cursor.execute('SELECT filename FROM books WHERE author_id = ?', (user_id,))
    books = cursor.fetchall()
    
    for book in books:
        try:
            os.remove(os.path.join(app.config['UPLOAD_FOLDER'], book[0]))
        except OSError:
            pass
    
    cursor.execute('DELETE FROM users WHERE id = ?', (user_id,))
    cursor.execute('DELETE FROM books WHERE author_id = ?', (user_id,))
    cursor.execute('DELETE FROM comments WHERE user_id = ?', (user_id,))
    conn.commit()
    conn.close()
    
    flash('Пользователь и все связанные данные удалены', 'success')
    return redirect(url_for('admin_panel'))

if __name__ == '__main__':
    app.run(debug=True)