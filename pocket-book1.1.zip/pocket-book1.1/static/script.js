document.addEventListener('DOMContentLoaded', function() {
    // Анимация при отправке форм
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
      form.addEventListener('submit', function() {
        const loader = this.querySelector('.form-loader');
        if (loader) loader.style.display = 'flex';
      });
    });
    // Рейтинг звездами
const ratingStars = document.querySelectorAll('#rating-stars .fa-star');
if (ratingStars.length > 0) {
  ratingStars.forEach(star => {
    star.addEventListener('click', function() {
      const rating = this.getAttribute('data-rating');
      document.getElementById('rating-value').value = rating;
      
      ratingStars.forEach((s, index) => {
        if (index < rating) {
          s.classList.remove('far');
          s.classList.add('fas');
        } else {
          s.classList.remove('fas');
          s.classList.add('far');
        }
      });
    });
    
    star.addEventListener('mouseover', function() {
      const hoverRating = this.getAttribute('data-rating');
      ratingStars.forEach((s, index) => {
        if (index < hoverRating) {
          s.classList.add('hover');
        } else {
          s.classList.remove('hover');
        }
      });
    });
    
    star.addEventListener('mouseout', function() {
      ratingStars.forEach(s => s.classList.remove('hover'));
    });
  });
}
    // Плавная прокрутка
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
          behavior: 'smooth'
        });
      });
    });
  });