document.addEventListener('DOMContentLoaded', function() {
    
    const initRatingSystem = () => {
        const starsContainer = document.getElementById('rating-stars');
        if (!starsContainer) return;

        const stars = starsContainer.querySelectorAll('.star');
        const ratingInput = document.getElementById('rating-value');

        stars.forEach(star => {
            star.addEventListener('click', function() {
                const rating = parseInt(this.getAttribute('data-rating'));
                ratingInput.value = rating;
                updateStarsDisplay(rating);
            });

            star.addEventListener('mouseover', function() {
                const hoverRating = parseInt(this.getAttribute('data-rating'));
                stars.forEach((s, index) => {
                    const icon = s.querySelector('i');
                    if (index < hoverRating) {
                        icon.classList.add('fas');
                        icon.classList.remove('far');
                    } else {
                        icon.classList.add('far');
                        icon.classList.remove('fas');
                    }
                });
            });

            star.addEventListener('mouseout', function() {
                const currentRating = parseInt(ratingInput.value) || 0;
                updateStarsDisplay(currentRating);
            });
        });

        
        if (ratingInput && ratingInput.value) {
            updateStarsDisplay(parseInt(ratingInput.value));
        }
    };

   
    const updateStarsDisplay = (rating) => {
        const stars = document.querySelectorAll('#rating-stars .star');
        stars.forEach((star, index) => {
            const icon = star.querySelector('i');
            if (index < rating) {
                icon.classList.add('fas');
                icon.classList.remove('far');
            } else {
                icon.classList.add('far');
                icon.classList.remove('fas');
            }
        });
    };

    
    const reviewForm = document.getElementById('review-form');
    if (reviewForm) {
        reviewForm.addEventListener('submit', function(e) {
            const rating = document.getElementById('rating-value').value;
            if (!rating) {
                e.preventDefault();
                alert('Пожалуйста, поставьте оценку перед отправкой отзыва');
                return false;
            }
            return true;
        });
    }

   
    const searchInput = document.getElementById('search-input');
    const liveResults = document.getElementById('live-results');
    const searchForm = document.getElementById('search-form');
    let searchTimer;
    
    if (searchInput && liveResults) {
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimer);
            const query = this.value.trim();
            
            if (query.length < 2) {
                liveResults.style.display = 'none';
                return;
            }
            
            searchTimer = setTimeout(() => {
                fetch(`/search?q=${encodeURIComponent(query)}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data && data.length > 0) {
                            liveResults.innerHTML = data.map(book => `
                                <div class="search-result" data-id="${book.id}">
                                    <a href="/book/${book.id}">
                                        <strong>${book.title}</strong>
                                        <span>Автор: ${book.author}</span>
                                    </a>
                                </div>
                            `).join('');
                            liveResults.style.display = 'block';
                        } else {
                            liveResults.innerHTML = '<div class="no-results">Ничего не найдено</div>';
                            liveResults.style.display = 'block';
                        }
                    })
                    .catch(error => {
                        console.error('Ошибка поиска:', error);
                        liveResults.style.display = 'none';
                    });
            }, 300);
        });
        
        document.addEventListener('click', function(e) {
            if (!searchForm.contains(e.target)) {
                liveResults.style.display = 'none';
            }
        });
    }

    
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function() {
            const loader = this.querySelector('.form-loader');
            if (loader) loader.style.display = 'flex';
        });
    });

    
    initRatingSystem();
});